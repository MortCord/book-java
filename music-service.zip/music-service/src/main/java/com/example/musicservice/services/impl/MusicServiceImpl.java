package com.example.musicservice.services.impl;

import com.example.musicservice.entities.Music;
import com.example.musicservice.repositories.MusicRepository;
import com.example.musicservice.services.MusicService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@AllArgsConstructor
public class MusicServiceImpl implements MusicService {

    private MusicRepository musicRepository;

    @Override
    public List<Music> getAllMusic() {
        return musicRepository.findAll();
    }

    @Override
    public Music saveMusic(Music music) {
        return musicRepository.save(music);
    }

    @Override
    public Music getMusicById(Long id) {
        return musicRepository.findById(id).get();
    }

    @Override
    public Music editMusic(Music music) {
        return musicRepository.save(music);
    }

    @Override
    public void removeMusicById(Long id) {
        musicRepository.deleteById(id);
    }
}

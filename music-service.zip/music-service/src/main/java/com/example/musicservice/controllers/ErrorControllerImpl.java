package com.example.musicservice.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ErrorControllerImpl implements ErrorController {
//    private static final String PATH = "/error";
//    @RequestMapping(value = PATH)
//    String error(){
//        return "error";
//    }
//
//    @Override
//    public String getErrorPath(){
//        return PATH;
//    }
}

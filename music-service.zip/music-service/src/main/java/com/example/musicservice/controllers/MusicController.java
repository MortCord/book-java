package com.example.musicservice.controllers;

import com.example.musicservice.entities.Music;
import com.example.musicservice.services.MusicService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.xml.transform.ErrorListener;
import java.util.ArrayList;

@Controller
public class MusicController {
    private MusicService musicService;

    private ArrayList wordsList = new ArrayList<String>();

    public MusicController(MusicService musicService){
        this.musicService = musicService;
        wordsList.add("test");
        wordsList.add("example");
        wordsList.add("example@gmail.com");
        wordsList.add("test@gmail.com");
    }
    @GetMapping("/music")
    public String listMusic(Model model){
        model.addAttribute("music", musicService.getAllMusic());
        return "music";
    }
    @GetMapping("/music/new")
    public String addMusic(Model model){
        Music music = new Music();
        model.addAttribute("music", music);
        return "AddMusic";
    }
    @PostMapping("/music")
    public String saveMusic(@ModelAttribute("music") Music music){
        musicService.saveMusic(music);
        return "redirect:/music";
    }
    @GetMapping("/music/edit/{id}")
    public String editMusicForm(@PathVariable Long id, Model model){
        model.addAttribute("music",musicService.getMusicById(id));
        return "EditMusic";
    }
    @PostMapping("/music/{id}")
    public String editMusic(@PathVariable Long id, @ModelAttribute("music") Music music){
        Music existMusic = musicService.getMusicById(id);


        existMusic.setAuthorName(music.getAuthorName());
        existMusic.setMusicName(music.getMusicName());
        existMusic.setAuthorEmail(music.getAuthorEmail());

        musicService.editMusic(existMusic);

        return "redirect:/music";
    }
    @GetMapping("/music/{id}")
    public String removeMusic(@PathVariable Long id){
        musicService.removeMusicById(id);

        return "redirect:/music";
    }

//    @RequestMapping("/error")
//    public String error(){
//        return "ErrorPage";
//    }


}

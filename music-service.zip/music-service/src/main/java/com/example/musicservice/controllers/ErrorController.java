package com.example.musicservice.controllers;

public interface ErrorController {
//    public String getErrorPath();
}

package com.example.musicservice.services;

import com.example.musicservice.entities.Music;

import java.util.List;

public interface MusicService {
    List<Music> getAllMusic();

    Music saveMusic(Music music);

    Music getMusicById(Long id);

    Music editMusic(Music music);

    void removeMusicById(Long id);
}

package com.example.musicservice.entities;

import jakarta.persistence.*;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;
@Entity
@Table(name = "musics")
public class Music {
    @Getter
    @Setter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Getter
    @Setter
    @Column(name = "author_name", nullable = false)
    private String authorName;
    @Getter
    @Setter
    @Column(name = "music_name")
    private String musicName;
    @Getter
    @Setter
    @Column(name = "author_email")
    private String authorEmail;

    public Music(){

    }

    public Music(String authorName, String musicName, String authorEmail){
        super();
        this.authorName = authorName;
        this.musicName = musicName;
        this.authorEmail = authorEmail;
    }
}

package com.example.musicservice.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import java.time.ZonedDateTime;
@AllArgsConstructor
public class ApiException {
    @Getter
    private final String message;
    @Getter
    private final Throwable throwable;
    @Getter
    private final HttpStatus httpStatus;
    @Getter
    private final ZonedDateTime time;

}
